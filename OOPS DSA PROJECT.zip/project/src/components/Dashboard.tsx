import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { X, Package, Heart, LogOut, User, ShoppingBag, Clock } from 'lucide-react';
import { Order, Product, CartItem } from '../types';
import { useAuth } from '../contexts/AuthContext';

interface DashboardProps {
  orders: Order[];
  favorites: string[];
  products: Product[];
  onClose: () => void;
  toggleFavorite: (productId: string) => void;
  addToCart: (product: Product) => void;
}

const Dashboard: React.FC<DashboardProps> = ({
  orders,
  favorites,
  products,
  onClose,
  toggleFavorite,
  addToCart
}) => {
  const navigate = useNavigate();
  const { user, logout } = useAuth();
  const [activeTab, setActiveTab] = useState<'profile' | 'orders' | 'favorites'>('profile');
  
  const favoriteProducts = products.filter(product => favorites.includes(product.id));
  
  const getStatusColor = (status: Order['status']) => {
    switch (status) {
      case 'pending':
        return 'bg-yellow-100 text-yellow-800';
      case 'processing':
        return 'bg-blue-100 text-blue-800';
      case 'shipped':
        return 'bg-purple-100 text-purple-800';
      case 'delivered':
        return 'bg-green-100 text-green-800';
      case 'cancelled':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const handleSignOut = () => {
    logout();
    navigate('/login');
  };
  
  return (
    <div className="fixed inset-0 z-50 overflow-hidden">
      <div className="absolute inset-0 bg-gray-500 bg-opacity-75 transition-opacity" onClick={onClose}></div>
      
      <div className="fixed inset-y-0 right-0 max-w-full flex">
        <div className="w-screen max-w-md">
          <div className="h-full flex flex-col bg-white shadow-xl">
            <div className="flex items-start justify-between p-4 border-b border-gray-200">
              <h2 className="text-lg font-medium text-gray-900">My Account</h2>
              <button
                type="button"
                className="-m-2 p-2 text-gray-400 hover:text-gray-500"
                onClick={onClose}
              >
                <span className="sr-only">Close panel</span>
                <X className="h-6 w-6" aria-hidden="true" />
              </button>
            </div>
            
            <div className="flex border-b border-gray-200">
              <button
                className={`flex-1 py-4 px-1 text-center font-medium text-sm ${
                  activeTab === 'profile' ? 'text-green-600 border-b-2 border-green-600' : 'text-gray-500 hover:text-gray-700'
                }`}
                onClick={() => setActiveTab('profile')}
              >
                <User className="h-5 w-5 mx-auto mb-1" />
                Profile
              </button>
              <button
                className={`flex-1 py-4 px-1 text-center font-medium text-sm ${
                  activeTab === 'orders' ? 'text-green-600 border-b-2 border-green-600' : 'text-gray-500 hover:text-gray-700'
                }`}
                onClick={() => setActiveTab('orders')}
              >
                <Package className="h-5 w-5 mx-auto mb-1" />
                Orders
              </button>
              <button
                className={`flex-1 py-4 px-1 text-center font-medium text-sm ${
                  activeTab === 'favorites' ? 'text-green-600 border-b-2 border-green-600' : 'text-gray-500 hover:text-gray-700'
                }`}
                onClick={() => setActiveTab('favorites')}
              >
                <Heart className="h-5 w-5 mx-auto mb-1" />
                Favorites
              </button>
            </div>
            
            <div className="flex-1 overflow-y-auto p-4">
              {activeTab === 'profile' && user && (
                <div>
                  <div className="flex items-center mb-6">
                    <div className="h-16 w-16 rounded-full bg-green-100 flex items-center justify-center text-green-600">
                      <User className="h-8 w-8" />
                    </div>
                    <div className="ml-4">
                      <h3 className="text-lg font-medium text-gray-900">{user.name}</h3>
                      <p className="text-sm text-gray-500">{user.email}</p>
                    </div>
                  </div>
                  
                  <div className="space-y-6">
                    <div>
                      <h4 className="text-sm font-medium text-gray-900 mb-2">Personal Information</h4>
                      <div className="bg-gray-50 p-4 rounded-md">
                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <p className="text-xs text-gray-500">Full Name</p>
                            <p className="text-sm font-medium">{user.name}</p>
                          </div>
                          <div>
                            <p className="text-xs text-gray-500">Email</p>
                            <p className="text-sm font-medium">{user.email}</p>
                          </div>
                          <div>
                            <p className="text-xs text-gray-500">Phone</p>
                            <p className="text-sm font-medium">{user.phone}</p>
                          </div>
                          <div>
                            <p className="text-xs text-gray-500">Member Since</p>
                            <p className="text-sm font-medium">{user.memberSince}</p>
                          </div>
                          <div>
                            <p className="text-xs text-gray-500">Account Type</p>
                            <p className="text-sm font-medium capitalize">{user.type}</p>
                          </div>
                        </div>
                      </div>
                    </div>
                    
                    <div>
                      <h4 className="text-sm font-medium text-gray-900 mb-2">Address</h4>
                      <div className="bg-gray-50 p-4 rounded-md">
                        <p className="text-sm">{user.address}</p>
                      </div>
                    </div>
                    
                    <div>
                      <h4 className="text-sm font-medium text-gray-900 mb-2">Payment Methods</h4>
                      <div className="bg-gray-50 p-4 rounded-md flex items-center justify-between">
                        <div className="flex items-center">
                          <div className="h-8 w-12 bg-blue-100 rounded flex items-center justify-center text-blue-800 font-bold text-xs">VISA</div>
                          <span className="ml-3 text-sm">•••• 4242</span>
                        </div>
                        <span className="text-xs text-gray-500">Expires 12/28</span>
                      </div>
                    </div>
                  </div>
                  
                  <div className="mt-8">
                    <button 
                      onClick={handleSignOut}
                      className="flex items-center text-red-600 font-medium text-sm"
                    >
                      <LogOut className="h-4 w-4 mr-2" />
                      Sign Out
                    </button>
                  </div>
                </div>
              )}
              
              {activeTab === 'orders' && (
                <div>
                  <h3 className="text-lg font-medium text-gray-900 mb-4">Your Orders</h3>
                  
                  {orders.length === 0 ? (
                    <div className="text-center py-8">
                      <Package className="mx-auto h-12 w-12 text-gray-400" />
                      <h3 className="mt-2 text-sm font-medium text-gray-900">No orders yet</h3>
                      <p className="mt-1 text-sm text-gray-500">Start shopping to place your first order.</p>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      {orders.map((order) => (
                        <div key={order.id} className="bg-white border border-gray-200 rounded-lg overflow-hidden">
                          <div className="p-4 border-b border-gray-200">
                            <div className="flex justify-between items-center">
                              <div>
                                <p className="text-sm font-medium text-gray-900">Order #{order.id}</p>
                                <p className="text-xs text-gray-500">{order.date}</p>
                              </div>
                              <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${getStatusColor(order.status)}`}>
                                {order.status.charAt(0).toUpperCase() + order.status.slice(1)}
                              </span>
                            </div>
                          </div>
                          
                          <div className="p-4">
                            <ul className="divide-y divide-gray-200">
                              {order.items.map((item) => (
                                <li key={item.product.id} className="py-2 flex items-center">
                                  <img 
                                    src={item.product.image} 
                                    alt={item.product.name}
                                    className="h-10 w-10 rounded object-cover"
                                  />
                                  <div className="ml-3 flex-1">
                                    <p className="text-sm font-medium text-gray-900">{item.product.name}</p>
                                    <p className="text-xs text-gray-500">Qty: {item.quantity}</p>
                                  </div>
                                  <p className="text-sm font-medium text-gray-900">
                                    ${(item.product.price * item.quantity).toFixed(2)}
                                  </p>
                                </li>
                              ))}
                            </ul>
                            
                            <div className="mt-4 pt-4 border-t border-gray-200">
                              <div className="flex justify-between text-sm">
                                <p className="font-medium text-gray-900">Total</p>
                                <p className="font-medium text-gray-900">${order.total.toFixed(2)}</p>
                              </div>
                              
                              <div className="mt-4 flex justify-between items-center">
                                <div className="flex items-center text-xs text-gray-500">
                                  <Clock className="h-4 w-4 mr-1" />
                                  {order.status === 'delivered' ? 'Delivered on ' : 'Estimated delivery by '}
                                  {new Date(order.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
                                </div>
                                
                                <button className="text-xs font-medium text-green-600">
                                  Track Order
                                </button>
                              </div>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}
              
              {activeTab === 'favorites' && (
                <div>
                  <h3 className="text-lg font-medium text-gray-900 mb-4">Your Favorites</h3>
                  
                  {favoriteProducts.length === 0 ? (
                    <div className="text-center py-8">
                      <Heart className="mx-auto h-12 w-12 text-gray-400" />
                      <h3 className="mt-2 text-sm font-medium text-gray-900">No favorites yet</h3>
                      <p className="mt-1 text-sm text-gray-500">Start adding products to your favorites.</p>
                    </div>
                  ) : (
                    <div className="grid grid-cols-1 gap-4">
                      {favoriteProducts.map((product) => (
                        <div key={product.id} className="flex border border-gray-200 rounded-lg overflow-hidden">
                          <img 
                            src={product.image} 
                            alt={product.name}
                            className="h-24 w-24 object-cover"
                          />
                          <div className="flex-1 p-4 flex flex-col">
                            <div className="flex-1">
                              <h4 className="text-sm font-medium text-gray-900">{product.name}</h4>
                              <p className="text-sm text-gray-500 line-clamp-1">{product.description}</p>
                              <p className="text-sm font-medium text-gray-900 mt-1">${product.price.toFixed(2)} / {product.unit}</p>
                            </div>
                            <div className="flex justify-between items-center mt-2">
                              <button
                                onClick={() => toggleFavorite(product.id)}
                                className="text-xs font-medium text-red-600 flex items-center"
                              >
                                <Heart className="h-4 w-4 mr-1 fill-red-500 text-red-500" />
                                Remove
                              </button>
                              <button
                                onClick={() => addToCart(product)}
                                disabled={product.stock <= 0}
                                className={`px-3 py-1 rounded text-xs font-medium ${
                                  product.stock > 0 
                                    ? 'bg-green-600 text-white hover:bg-green-700' 
                                    : 'bg-gray-200 text-gray-400 cursor-not-allowed'
                                }`}
                              >
                                {product.stock > 0 ? 'Add to Cart' : 'Out of Stock'}
                              </button>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;